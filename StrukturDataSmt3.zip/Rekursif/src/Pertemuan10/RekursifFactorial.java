package Pertemuan10;

import javax.swing.JOptionPane;

public class RekursifFactorial {

    static int faktorial(int n) {
        if (n == 1) {
            return 1;
        } else {
            return n * faktorial(n - 1);
        }
    }

    public static void main(String[] args) {
        int n;
        n = Integer.parseInt(JOptionPane.showInputDialog
        ("Masukkan Nilai yang ingin di-faktorial : "));
        JOptionPane.showMessageDialog(null, n + "! = " + faktorial(n));
    }
}
