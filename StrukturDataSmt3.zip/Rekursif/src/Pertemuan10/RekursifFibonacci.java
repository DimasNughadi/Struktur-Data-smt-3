package Pertemuan10;

import javax.swing.JOptionPane;

public class RekursifFibonacci {

    static long fibonacci(long s) {
        if (s == 0 || s == 1) {
            return s;
        } else {
            return fibonacci(s - 1) + fibonacci(s - 2);
        }
    }

    public static void main(String[] args) {
        int num = Integer.parseInt(JOptionPane.showInputDialog
        ("Masukkan Jumlah Deret: "));
        System.out.println("");
        for (int i = 1; i <= num; i++) {
            System.out.print
        (" " + fibonacci(i));
        }
    }
}
