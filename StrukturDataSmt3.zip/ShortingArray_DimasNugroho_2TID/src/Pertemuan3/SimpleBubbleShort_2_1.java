package Pertemuan3;

public class SimpleBubbleShort_2_1 {
    public static void main(String[] args) {
        String [] arr={"now", "is", "time", "flower", "all"};
        String temp;
        
        for (int i = 0; i<(arr.length); i++){
            for (int j =(arr.length-1); j > i; j--){
                if (arr[j].compareTo(arr[j-1]) < 0){
                    temp = arr[j];
                    arr[j] = arr[j-1];
                    arr[j-1] = temp;
                }
            }
            System.out.println(arr[i]);
        }
    }
}    
