package Pertemuan3;

import javax.swing.JOptionPane;

public class TugasSimpleBubbleShort_2_1 {
    public static void main(String[] args) {
        int e = Integer.parseInt(JOptionPane.showInputDialog("Masukan Panjang Array: "));
        String arr [] = new String [e];
        String temp;
        
        for (int i = 0; i < arr.length; i++){
            String nilai = JOptionPane.showInputDialog("Masukan String ke-"+(i+1));
            arr[i] = nilai;
        }
        
        for (int i = 0; i<(arr.length); i++){
            for (int j =(arr.length-1); j > i; j--){
                if (arr[j].compareTo(arr[j-1]) < 0){
                    temp = arr[j];
                    arr[j] = arr[j-1];
                    arr[j-1] = temp;
                }
            }
            System.out.println(arr[i]);
        }
    }
}
