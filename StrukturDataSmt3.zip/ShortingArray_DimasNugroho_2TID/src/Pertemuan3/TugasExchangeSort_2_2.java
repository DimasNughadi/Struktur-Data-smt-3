package Pertemuan3;

import javax.swing.JOptionPane;

public class TugasExchangeSort_2_2 {
    public static void main(String[] args) {
        int e = Integer.parseInt(JOptionPane.showInputDialog("Masukan Panjang Array: "));
        int array [] = new int [e];
        int i, j, temp;
        int arrayLength = array.length;
        
        for (i = 0; i < array.length; i++){
            int nilai = Integer.parseInt(JOptionPane.showInputDialog("Masukan nilai ke-"+(i+1)));
            array[i] = nilai;
        }
        
        for (i = 0; i < arrayLength; i++){
            for (j = (i+1); j < arrayLength; j++){
                if (array[i] > array[j]){
                    temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
            System.out.println(array[i]);
        }
    }
}
