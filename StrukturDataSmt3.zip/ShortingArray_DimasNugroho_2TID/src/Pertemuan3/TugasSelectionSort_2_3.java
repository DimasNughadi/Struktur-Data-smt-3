package Pertemuan3;

import javax.swing.JOptionPane;

public class TugasSelectionSort_2_3 {
    public static void main(String[] args) {
        int e = Integer.parseInt(JOptionPane.showInputDialog("Masukan Panjang Array: "));
        int angka [] = new int [e];
        int i, j, temp, awal;
        
        for (i = 0; i < angka.length; i++){
            int nilai = Integer.parseInt(JOptionPane.showInputDialog("Masukan nilai ke-"+(i+1)));
            angka[i] = nilai;
        }
        
        for (i = 0; i<(angka.length-1); i++){
            awal = i;
            for (j = i+1; j<angka.length; j++){
                if (angka [awal] > angka[j]){
                    awal = j;
                }
            }
            temp = angka[i];
            angka[i] = angka[awal];
            angka[awal] = temp;
            System.out.println(angka[i]);
        }
    }
}
