package Program6_1;

/**
 *
 * @author DIMAS NUGROHO
 */
public class SLLNC {

    public static void main(String[] args) {
        linkSLLNC linkedlist = new linkSLLNC();

        System.out.println("linkedlist.insertDepan(5);");
        linkedlist.insertDepan(5);
        linkedlist.printDepan();
        System.out.println();
        System.out.println("linkedlist.insertDepan(2);");
        linkedlist.insertDepan(2);
        linkedlist.printDepan();
        System.out.println();
        System.out.println("linkedlist.insertDepan(7);");
        linkedlist.insertDepan(7);
        linkedlist.printDepan();
        System.out.println();
        System.out.println("linkedlist.insertBelakang(9);");
        linkedlist.insertBelakang(9);
        linkedlist.printDepan();
        System.out.println();
        System.out.println("linkedlist.insertDepan(6);");
        linkedlist.insertDepan(6);
        linkedlist.printDepan();
        System.out.println();
        System.out.println("linkedlist.hapusDepan();");
        linkedlist.hapusDepan();
        linkedlist.printDepan();
        System.out.println();
        System.out.println("linkedlist.hapusBelakang();");
        linkedlist.hapusBelakang();
//        System.out.println();
        linkedlist.printDepan();
        System.out.println();
        System.out.println("linkedlist.insertBelakang(4);");
        linkedlist.insertBelakang(4);
        linkedlist.printDepan();
        System.out.println();
    }
}
