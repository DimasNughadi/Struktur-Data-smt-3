package Program6_1;

/**
 *
 * @author DIMAS NUGROHO
 */
public class linkSLLNC {

    public int data;
    public linkSLLNC next;

    public linkSLLNC() {

    }

    public linkSLLNC(int d) {
        data = d;
        next = null;
    }

    linkSLLNC head;
    linkSLLNC bantu;
    linkSLLNC tail;

    public boolean isEmpty() {
        if (head == null) {
            return true;
        } else {
            return false;
        }
    }

    public void insertDepan(int databaru) {
        linkSLLNC baru;
        baru = new linkSLLNC(databaru);
        baru.next = baru;

        if (isEmpty() == true) {
            head = baru;
            head.next = null;
        } else {
            baru.next = head;
            head = baru;
        }
    }

    public void insertBelakang(int databaru) {
        linkSLLNC baru = new linkSLLNC(databaru);

        if (head == null) {
            head = new linkSLLNC(databaru);
            return;
        }
        baru.next = null;

        linkSLLNC last = head;

        while (last.next != null) {
            last = last.next;
        }
        last.next = baru;
        return;
    }

    public void hapusDepan() {
        linkSLLNC hapus;
        if (head.next == null) {
            head = null;
        } else {
            hapus = head;
            head = head.next;
            hapus = null;
        }
    }

    public void hapusBelakang() {
        linkSLLNC hapus;
        if (head == null) {
            return;
        }
        if (head.next == null) {
            return;
        }
        linkSLLNC second_last = head;
        while (second_last.next.next != null) {
            second_last = second_last.next;
        }

        second_last.next = null;
        return;
    }

    public void printDepan() {
        if (isEmpty() == false) {
            bantu = head;
            while (bantu != null) {
                bantu.displaynode();
                bantu = bantu.next;
            }
        }
    }

    public void displaynode() {
        System.out.print(data + " ");
    }
}
