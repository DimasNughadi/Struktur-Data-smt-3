package Program6_2;

/**
 *
 * @author DIMAS NUGROHO
 */
public class SLLC {
    public static void main(String[] args) {
        linkSLLC linkedlist = new linkSLLC(100);
        linkedlist.insertDepan(5);
        linkedlist.insertDepan(2);
        linkedlist.insertDepan(7);
        linkedlist.insertBelakang(9);
        linkedlist.printDepan();
        System.out.println();
        linkedlist.insertDepan(6);
        System.out.println();
        linkedlist.printDepan();
        linkedlist.hapusDepan();
        System.out.println();
        linkedlist.printDepan();
        linkedlist.hapusBelakang();
        System.out.println();
        linkedlist.printDepan();
        linkedlist.insertBelakang(4);
        System.out.println();
        linkedlist.printDepan();
    }
}
