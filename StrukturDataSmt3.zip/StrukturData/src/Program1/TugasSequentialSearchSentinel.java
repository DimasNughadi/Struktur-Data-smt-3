package Program1;

import javax.swing.JOptionPane;

public class TugasSequentialSearchSentinel {
    public static void main(String[] args) {
        int e = Integer.parseInt(JOptionPane.showInputDialog("Masukan Jumlah Elemen Array"));
        int [] a = new int[e+2];
        int j = 0;
        int i = 0;
        int flag = 0;  
        
        for (i = 0; i < e; i++){
            int nilai = Integer.parseInt(JOptionPane.showInputDialog("Masukan nilai ke-"+(i+1)));
            a[i] = nilai;
        }
        
        j = Integer.parseInt(JOptionPane.showInputDialog("Masukan Angka Yang Dicari: "));
        a[e+1] = j;
        while (j != a[flag]){
            flag++;
        }
        if (flag <e-1){
            System.out.println("Data yang dicari: "+ j + " ada, Ditemukan pada index ke-"+flag);
        }else{
            System.out.println("Data yang dicari: "+ j + " tidak ada ");
        }
    }
}
