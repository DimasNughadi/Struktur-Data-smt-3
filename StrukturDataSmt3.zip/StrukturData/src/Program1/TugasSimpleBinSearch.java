package Program1;

import javax.swing.JOptionPane;

public class TugasSimpleBinSearch {
    public static void main(String[] args) {
        int e = Integer.parseInt(JOptionPane.showInputDialog("Masukan Panjang Array: "));
        int c [] = new int [e];
        int i ;
        int j = 0;
        int awal = 0;
        int akhir;
        int nt;
        int flag = 0;
        int cari ;
        
        for (i = 0; i < c.length; i++){
            int nilai = Integer.parseInt(JOptionPane.showInputDialog("Masukan nilai ke-"+(i+1)));
            c[i] = nilai;
        }
        
        cari = Integer.parseInt(JOptionPane.showInputDialog("Masukan angka yang dicari: "));
        
        akhir  = c.length-1;
        while (awal <= akhir && flag == 0){
            nt = Math.abs((awal+akhir)/2);
            if (c[nt] == cari){
                flag = 1;
            }else if (cari < c[nt]){
                akhir = nt-1;
            }else{
                awal = nt +1;
            }
            
        }if (flag == 1){
            JOptionPane.showMessageDialog(null, "Data ditemukan !!");
        }else{
            JOptionPane.showMessageDialog(null, "Data tidak ditemukan !!");
        }
        System.exit(0);
    }
}
