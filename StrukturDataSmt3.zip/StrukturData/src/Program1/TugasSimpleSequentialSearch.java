package Program1;

import javax.swing.JOptionPane;

public class TugasSimpleSequentialSearch {
    public static void main(String[] args) {
        int e = Integer.parseInt(JOptionPane.showInputDialog("Masukan Jumlah Elemen Array"));
        int [] a = new int[e];
        int j = 0;
        int flag = 0;
        int i = 0;
        
        for (i = 0; i < a.length; i++){
            int nilai = Integer.parseInt(JOptionPane.showInputDialog("Masukan nilai array ke-"+(i+1)));
            a[i] = nilai;
        }
        
        j = Integer.parseInt(JOptionPane.showInputDialog("Masukan Angka yang dicari: "));
        for(i = 0; i<a.length; i++){
            if (j == a[i]){
                flag = 1;
                break;
            }else{
                flag = 0;
            }
        }
        if (flag == 1){
            System.out.println("Data yang dicari: "+ j +" ada,Ditemukan pada index ke-"+i);
        }else{
            System.out.println("Data yang dicari: "+ j +" tidak ada");
        }
    }
}
