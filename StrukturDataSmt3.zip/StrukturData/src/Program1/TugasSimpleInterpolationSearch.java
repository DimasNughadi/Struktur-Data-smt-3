package Program1;

import static Program1.SimpleInterpolationSearch.a;
import javax.swing.JOptionPane;

public class TugasSimpleInterpolationSearch {
    public static void main(String[] args) {
        int e = Integer.parseInt(JOptionPane.showInputDialog("Masukan Panjang Array: "));
        int c [] = new int [e];
        int i ;
        int posisi;
        int cari;
        for (i = 0; i < c.length; i++){
            int nilai = Integer.parseInt(JOptionPane.showInputDialog("Masukan nilai ke-"+(i+1)));
            c[i] = nilai;
        }
        cari = Integer.parseInt(JOptionPane.showInputDialog("Masukan angka yang dicari: "));
        posisi = search(cari, a.length);
        if (posisi == -1) {
            JOptionPane.showMessageDialog(null, "Data tidak ditemukan !!");
        } else {
            JOptionPane.showMessageDialog(null, "Data ditemukan !!");
        }
    }
    public static int search(int b, int n) {
        int awal = 0;
        int akhir;
        int nt;
        akhir = n - 1;
        do {
            nt = (int) ((b - a[awal]) * (akhir - awal) + awal) / (a[akhir] - a[awal]);
            if (a[nt] == b) {
                return nt;
            } else if (b < a[nt]) {
                akhir = nt - 1;
            } else {
                awal = nt + 1;
            }
        } while (b > a[awal] && b <= a[akhir]);
        return -1;
    }
}
