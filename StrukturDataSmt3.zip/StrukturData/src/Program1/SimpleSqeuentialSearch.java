package Program1;

import javax.swing.JOptionPane;

public class SimpleSqeuentialSearch {
    public static void main(String[] args) {
        int [] a = {1, 5, 7, 4, 8, 3, 6, 2, };
        int flag = 0;
        int i = 0;
//        MILIK DIMAS NUGROHO
        int j = Integer.parseInt(JOptionPane.showInputDialog("Masukan Angka yang dicari: "));
        for(i = 0; i<a.length; i++){
            if (j == a[i]){
                flag = 1;
                break;
            }else{
                flag = 0;
            }
        }
        if (flag == 1){
            System.out.println("Data yang dicari: "+ j +" ada, Ditemukan pada index ke-"+(i+1));
        }else{
            System.out.println("Data yang dicari: "+ j +" tidak ada");
        }
    }
}
