package UAS;

/**
 *
 * @author DIMAS NUGROHO
 */

public class UAS_SDA_A {
    // minimum index finder

    static int minIndex(int arr[], int s, int e) {
        int sml = Integer.MAX_VALUE;
        int mindex = -1;

        for (int i = s; i < e; i++) {
            //kondisi untuk mencari index minimum
            if (sml > arr[i]) {
                sml = arr[i];
                mindex = i;
            }
        }
        return mindex;
    }

    static void fungsi(int arr[], int start_index, int end_index) {
        if (start_index >= end_index) {
            return;
        }
        int min_index;
        int temp;
        //call minIndex
        min_index = minIndex(arr, start_index, end_index);
        //swap the value of arr[start_index] and arr[minIndex]
        temp = arr[start_index];
        arr[start_index] = arr[min_index];
        arr[min_index] = temp;
        //call fungsi
        fungsi(arr, start_index + 1, end_index);
    }

    static void printArray(int arr[]) {
        int n = arr.length;
        for (int i = 0; i < n; ++i) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int arr[] = {5, 3, 7, 8, 1};
        //panggil fungsi()
        //print output array       
        System.out.println("Array awal :");
        printArray(arr);

        UAS_SDA_A obj = new UAS_SDA_A();
        obj.fungsi(arr, 0, arr.length);

        System.out.println("Array Setelah Terurut :");
        printArray(arr);
    }
}
