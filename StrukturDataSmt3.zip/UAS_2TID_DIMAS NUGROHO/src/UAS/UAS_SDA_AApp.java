package UAS;

/**
 *
 * @author DIMAS NUGROHO
 * TIPE SOAL : UAS_SDA_A
 */

public class UAS_SDA_AApp {
    public static void main(String[] args) {
        linkSLLC linkedList = new linkSLLC();
        linkedList.insertDepan(5);
        linkedList.insertDepan(2);
        linkedList.insertDepan(7);
        linkedList.insertBelakang(9);
        linkedList.printDepan();
        linkedList.insertDepan(6);
        System.out.println();
        linkedList.printDepan();
        linkedList.hapusDepan();
        System.out.println();
        linkedList.printDepan();
        linkedList.hapusBelakang();
        System.out.println();
        linkedList.printDepan();
        linkedList.insertBelakang(4);
        linkedList.insertTengah(2, 6);
        linkedList.hapusTengah(3);
        System.out.println();
        linkedList.printDepan();
    }
}
