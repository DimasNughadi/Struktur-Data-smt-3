package UAS;

/**
 *
 * @author DIMAS NUGROHO
 */
public class linkSLLC {

    public int data;
    public linkSLLC next;
    linkSLLC head;
    linkSLLC bantu;

    public linkSLLC() {
    }
    
    public linkSLLC(int d) {
        data = d;
        next = null;
    }

    public boolean isEmpty() {
        if (head == null) {
            return true;
        } else {
            return false;
        }
    }

    public void insertDepan(int databaru) {
        linkSLLC baru;
        baru = new linkSLLC(databaru);
        baru.next = baru;

        if (isEmpty() == true) {
            head = baru;
            head.next = head;
        } else {
            if (head.next == head) {
                baru.next = head;
                head.next = baru;
                head = baru;
            } else {
                bantu = head;
                while (bantu.next != head) {
                    bantu = bantu.next;
                }
                bantu.next = baru;
                baru.next = head;
                head = baru;
            }
        }
    }

    public void insertBelakang(int databaru) {
        linkSLLC baru;
        linkSLLC tail;
        baru = new linkSLLC(databaru);
        baru.next = baru;

        if (head == null) {
            head = baru;
            head.next = baru;
        } else {
            if (head.next == head) {
                head.next = baru;
                baru.next = head;
                head = baru;
            } else {
                tail = head;
                while (tail.next != head) {
                    tail = tail.next;
                }
                tail.next = baru;
                baru.next = head;
            }
        }
    }

    public void hapusDepan() {
        if (head.next == head) {
            head = null;
        } else {
            bantu = head;
            while (bantu.next != head) {
                bantu = bantu.next;
            }
            head = head.next;
            bantu.next = head;
        }
    }
    
    public void hapusBelakang() {
        if (head.next == head) {
            head = null;
        } else {
            while (bantu.next.next != head) {
                bantu = bantu.next;
            }
            bantu.next = head;
        }
    }

    public void printDepan() {
        if (isEmpty() == false) {
            bantu = head;
            do {
                bantu.displaynode();
                bantu = bantu.next;
            } while (bantu != head);
        }
    }

    public void displaynode() {
        System.out.print(data + " ");
    }
    
    //insert data ke-x --> a : posisi data
    public void insertTengah(int databaru, int a) {
        linkSLLC baru, bantu;
        if (head != null) {
            baru = new linkSLLC();
            bantu = head;

            for (int i = 1; i < databaru - 1; i++) {
                if (bantu.next != null) {
                    bantu = bantu.next;
                } else {
                    break;
                }
            }
            baru.data = a;
            baru.next = bantu.next;
            bantu.next = baru;
        }
    }
    
    //hapus data ke-posisi
    public void hapusTengah(int posisi) {
        linkSLLC hapus;
        int count = 1;
        bantu = head;
        while (bantu.next.next != head) {
            if (count == posisi - 1) {
                hapus = bantu.next; 
                bantu.next = hapus.next;
                break;
            }
            count++;
            bantu = bantu.next;
        }
    }
}
