package TeoriTugas;

import javax.swing.JOptionPane;

public class SearchAndSortingArraybubbleSort {

    public static void main(String[] args) {
        int array[] = {57, 39, 21, 89, 40, 33, 24, 10, 73};
        int temp, cari, akhir, nt;
        int awal = 0;
        int flag = 0;

        for (int i = 0; i < (array.length); i++) {
            for (int j = (array.length - 1); j > i; j--) {
                if (array[j] < (array[j - 1])) {
                    temp = array[j];
                    array[j] = array[j - 1];
                    array[j - 1] = temp;
                }
            }
        }
        cari = Integer.parseInt(JOptionPane.showInputDialog("Masukan angka yang dicari: "));
        akhir  = array.length-1;
        while (awal <= akhir && flag == 0){
            nt = Math.abs((awal+akhir)/2);
            if (array[nt] == cari){
                flag = 1;
            }else if (cari < array[nt]){
                akhir = nt-1;
            }else{
                awal = nt +1;
            }
            
        }if (flag == 1){
            JOptionPane.showMessageDialog(null, "Data ditemukan !!");
        }else{
            JOptionPane.showMessageDialog(null, "Data tidak ditemukan !!");
        }
        System.exit(0);
    }
}
