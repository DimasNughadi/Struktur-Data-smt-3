package Program7_1;

/**
 *
 * @author hp
 */
public class Nodes {
    int iData;
    Nodes leftChild;
    Nodes rightChild;
}
