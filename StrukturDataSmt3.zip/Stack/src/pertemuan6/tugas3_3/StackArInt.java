package pertemuan6.tugas3_3;

/**
 *
 * @author DIMAS NUGROHO
 */
public class StackArInt {
    private int maxSize;
    private int[] stackArray;
    private int top;
    
    public StackArInt(int s){
        maxSize = s;
        stackArray = new int[maxSize];
        top = -1;
    }
    public void push(int j){
        stackArray[++top] = j;
    }
    public int pop(){
        return stackArray[top--];
    }
    public int peek(){
        return stackArray[top];
    }
    public boolean isEmpty(){
        return (top == -1);
    }
    public boolean isFull(){
        return (top == maxSize - 1);
    }
    public int size(){
        return top + 1;
    }
    public int peekN(int n){
        return stackArray[n];
    }
}
