package pertemuan6.tugas3_3;

import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author DIMAS NUGROHO
 */
public class InfixEvaluate {
    public static void main(String[] args) throws IOException {
        String input, postfix;
        int output;
        
        while(true){
            input = JOptionPane.showInputDialog("Infix Form:");
            
            if ( input.equals("")) {
                break;
            }
            
            InfixToPostfix ITP = new InfixToPostfix();
            postfix = InfixToPostfix.Konversi(input);
            PostfixEvaluate proses = new PostfixEvaluate(postfix);
            output = proses.doParse();
            System.out.println("Hasil evaluasi adalah "+output);
        }
    }
}