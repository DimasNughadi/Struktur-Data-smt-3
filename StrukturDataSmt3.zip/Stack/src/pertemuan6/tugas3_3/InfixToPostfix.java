package pertemuan6.tugas3_3;

import java.util.Stack;
/**
 *
 * @author DIMAS NUGROHO
 */
public class InfixToPostfix {
    static int Operator(char op){
        switch (op){
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;                       
            case '^':
                return 3;
        }
        return -1;
    }
    
    static String Konversi(String s){
        String result = "";
        
        Stack<Character> stack = new Stack<>();
        
        for (int i = 0; i < s.length() ; i++) {
            char c = s.charAt(i);
            
            if (Character.isLetterOrDigit(c)){
                result += c;
            }else if (c == '('){
                stack.push(c);
            }else if (c == ')'){
                while (!stack.isEmpty() && stack.peek() != '('){
                    result += stack.pop();
                }
                stack.pop();
            }else{
                while (!stack.isEmpty() && Operator(c) <= Operator(stack.peek())){
                    result += stack.pop();
                }
                stack.push(c);
            }
        }
        while (!stack.isEmpty()){
            if (stack.peek() == '('){
                return "Invalid Expresion";
            }
            result += stack.pop();
        }
        return result;
    }
}
