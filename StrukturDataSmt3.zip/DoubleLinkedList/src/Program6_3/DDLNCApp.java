package Program6_3;

/**
 *
 * @author DIMAS NUGROHO
 */
public class DDLNCApp {
    public static void main(String[] args) {
        dLink link = new dLink();
        
        System.out.println("Insert Depan 6");
        link.insertDepan(6);
        link.PrintDepan();
        System.out.println();
        System.out.println("Insert Depan 3");
        link.insertDepan(3);
        link.PrintDepan();
        System.out.println();
        System.out.println("Insert Depan 9");
        link.insertDepan(9);
        link.PrintDepan();
        System.out.println();
        System.out.println("Print Belakang");
        link.printBelakang();
        System.out.println();
        System.out.println("Insert Belakang 7");
        link.insertBelakang(7);
        link.PrintDepan();
        System.out.println();
        System.out.println("Hapus Depan");
        link.hapusDepan();
        link.PrintDepan();
        System.out.println();
        System.out.println("Hapus Belakang");
        link.hapusBelakang();
        link.PrintDepan();
        System.out.println();
    }
}
