package Program6_3;

/**
 *
 * @author DIMAS NUGROHO
 */
public class dLink {

    public int data;
    public dLink next;
    public dLink previous;
    dLink head;
    dLink bantu;

    public dLink() {
    }

    public dLink(int d) {
        data = d;
        next = null;
        previous = null;
    }

    public boolean isEmpty() {
        if (head == null) {
            return true;
        } else {
            return false;
        }
    }

    public void insertDepan(int databaru) {
        dLink baru;
        baru = new dLink(databaru);
        baru.next = null;
        baru.previous = null;
        if (isEmpty() == true) {
            head = baru;
            head.next = null;
            head.previous = null;
        } else {
            head.previous = baru;
            baru.next = head;
            head = baru;
        }
    }

    public void insertBelakang(int databaru) {
        dLink baru, tail;
        baru = new dLink(databaru);
        baru.next = null;
        baru.previous = null;
        tail = head;
        if (isEmpty() == true) {
            head = baru;
            head.next = null;
            head.previous = null;
        } else {
            while (tail.next != null) {
                tail = tail.next;
            }
            tail.next = baru;
            baru.previous = tail;
        }
    }

    public void hapusDepan() {
        dLink hapus;
        hapus = head;
        if (head.next != null) {
            head = head.next;
            head.previous = null;
            hapus = null;
        }
    }

    public void hapusBelakang() {
        dLink hapus;
        if (isEmpty() == false) {
            if (head.next != null) {
                hapus = head;
                while (hapus.next != null) {
                    hapus = hapus.next;
                }
                hapus.previous.next = null;
            } else {
                head = null;
            }
        }
    }

    public void PrintDepan() {
        if (isEmpty() == false) {
            bantu = head;
            while (bantu != null) {
                bantu.displaynode();
                bantu = bantu.next;
            }
        }
    }

    public void printBelakang() {
        dLink bantu2;
        if (isEmpty() == false) {
            bantu = head;
            while (bantu.next != null) {
                bantu = bantu.next;
            }
            bantu2 = bantu;
            while (bantu2 != null) {
                bantu2.displaynode();
                bantu2 = bantu2.previous;
            }
        }
    }

    public void displaynode() {
        System.out.print(data + " ");
    }
}
