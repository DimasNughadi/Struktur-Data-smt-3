/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Program6_4;

/**
 *
 * @author DIMAS NUGROHO
 */
public class DLLC {
    link head;
    link bantu;
    
    public boolean isEmpty(){
        if (head == null) {
            return true;
        }else{
            return false;
        }
    }
    
    public void insertDepan(int databaru){
        link baru;
        baru = new link(databaru);
        baru.next = baru;
        baru.previous = baru;
        
        if (isEmpty() == true) {
            head = baru;
            head.next = head;
            head.previous = head;
        }else{
            bantu = head.previous;
            head.previous = baru;
            baru.next = head;
            head = baru;
            bantu.next = head;
            head.previous = bantu;
        }
    }
    
    public void insertBelakang(int databaru) {
        link baru;
        baru = new link(databaru);
        baru.next = baru;
        baru.previous = baru;
        
        if (isEmpty() == true) {
            head = baru;
            head.next = head;
            head.previous = head;
        }else{
            bantu = head.previous;
            bantu.next = baru;
            baru.previous = bantu;
            baru.next = head;
            head.previous = baru;
        }
    }
    
    public void hapusDepan(){
        link hapus;
        hapus = head;
        
        if (head.next != head) {
            bantu = head.previous;
            head = head.next;
            bantu.next = head;
            head.previous = bantu;
            hapus = null;
        }else{
            head = null;
        }
    }
    
    public void hapusBelakang(){
        link hapus;
        hapus = head;
        int temp;
      head.previous = bantu;  
        if (head.next != head) {
            bantu = head;
            while (bantu.next.next != head){
                bantu = bantu.next;
            }
            hapus = bantu.next;
            temp = hapus.data;
            bantu.next =head;
            hapus = null;
        }else{
            temp = head.data;
            head = null;
        }
    }
    
    public void printDepan(){
        if (isEmpty() == false) {
            bantu = head;
            do{
                bantu.displaynode();
                bantu = bantu.next;
            }while (bantu != head);
        }
    }
    
    public void printBelakang(){
        link bantu2;
        
        if (isEmpty() == false) {
            bantu = head;
            while (bantu.next != head){
                bantu = bantu.next;
            }
            bantu2 = bantu;
            
            do{
                bantu2.displaynode();
                bantu2 = bantu2.previous;
            }while (bantu2.previous != bantu);
                bantu2.displaynode();
        }
    }
    
    public static void main(String[] args) {
        DLLC linkedlist = new DLLC();
        linkedlist.insertDepan(5);
        linkedlist.insertDepan(2);
        linkedlist.insertDepan(7);
        linkedlist.insertBelakang(9);
        linkedlist.printDepan();
        System.out.println();
        linkedlist.insertDepan(6);
        linkedlist.printBelakang();
        linkedlist.hapusDepan();
        System.out.println();
        linkedlist.printDepan();
        linkedlist.hapusBelakang();
        System.out.println();
        linkedlist.printDepan();
    }
}
