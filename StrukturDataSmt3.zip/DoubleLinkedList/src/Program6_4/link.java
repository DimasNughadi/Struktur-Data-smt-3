/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Program6_4;

/**
 *
 * @author DIMAS NUGROHO
 */
public class link {
    public int data;
    public link next;
    public link previous;
    
    public link (int d){
        data = d;
        next = null;
        previous = null;
    }
    
    public void displaynode(){
        System.out.print(data+" ");
    }
}
