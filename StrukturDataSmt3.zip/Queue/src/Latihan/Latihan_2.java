/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Latihan;

import java.util.*;

public class Latihan_2 {

    public static void main(String[] args) {
        int j = 1;
        String output = "";
        PriorityQueue<member> queue = new PriorityQueue<>();

        member b1 = new member("Ani", "Classic", 3);
        member b2 = new member("Budi", "Platinum", 1);
        member b3 = new member("Risa", "Gold", 2);
        member b4 = new member("Deni", "Platinum", 1);

        queue.add(b1);
        queue.add(b2);
        queue.add(b3);
        queue.add(b4);
        System.out.println("Calling:");

        for (member b : queue) {
            output += ((j++) + " " +b.name+"\n");
        }
        System.out.println(output);
    }
}
