/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Latihan;

import javax.swing.JOptionPane;

/**
 *
 * @author DIMAS NUGROHO
 */
public class Latihan_1 {
    
    public static void main(String[] args) {
        int j = 1;
        String output = "";
        
        int Jumlah = Integer.parseInt(JOptionPane.showInputDialog("Masukan Jumlah Pesan : "));
        Latihan.Queue Item = new Latihan.Queue(Jumlah);
        Latihan.Queue Qty = new Latihan.Queue(Jumlah);

        for (int i = 0; i < Jumlah; i++) {
            String x = JOptionPane.showInputDialog("Masukan Item ke-" + (i + 1));
            Item.insertItem(x);
            int z = Integer.parseInt(JOptionPane.showInputDialog("Jumlah "+ x +" Yang Dipesan: "));
            Qty.insertQty(z);
        }

        while (!Item.isEmpty() && !Qty.isEmpty()) {
            String n = Item.removeItem();
            int n2 = Qty.removeQty();
            output += (j++) + ". " + n + " x" + n2 +"\n";
        }
        JOptionPane.showMessageDialog(null, output);
    }
}
