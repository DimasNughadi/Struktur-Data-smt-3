/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Latihan;

class BankXYZ {

    private int maxSize;
    private String[][] queArray;
    private int front;
    private int rear;
    private int nItems;

    public BankXYZ(int s) {
        maxSize = s;
        queArray = new String[maxSize][2];
        front = 0;
        rear = -1;
        nItems = 0;
    }

    public void insert(String i, String j) {

        int x;
        if (nItems == 0) {
            nItems++;
            queArray[0][0] = i;
            queArray[0][1] = j;
        } else {
            for (x = nItems - 1; x >= 0; x--) {
                if (i.compareTo(queArray[x][0]) < 0) {
                    queArray[x + 1][0] = queArray[x][0];
                    queArray[x + 1][1] = queArray[x][1];
                } else {
                    break;
                }
            }

            queArray[x + 1][0] = i;
            queArray[x + 1][1] = j;
            nItems++;
        }
    }

    public String remove() {
        if (front == maxSize) {
            front = 0;
        }
        String cs = "";
        switch (queArray[front][1]) {
            case "A":
                cs = "1";
                break;
            case "B":
                cs = "2";
                break;
            case "C":
                cs = "3";
                break;
            case "D":
                cs = "4";
                break;
            default:
                cs = "Keperluan yang anda masukkan salah";
        }

        String temp = "CS " + cs + " Memanggil: " + queArray[front][0] + "\n";
        front++;
        nItems--;
        return temp;
    }

    public String peekFront() {
        return "Item : " + queArray[front++][0] + "\nQty : " + queArray[front++][1];
    }

    public boolean isEmpty() {
        return (nItems == 0);
    }
}

/**
 *
 * @author hp
 */
public class Latihan_3 {

    public static void main(String[] args) {
        BankXYZ bank = new BankXYZ(5);
        bank.insert("Doni","A");
        bank.insert("Ghea","B");
        bank.insert("Pristine","D");
        bank.insert("Toni","A");
        bank.insert("Zidane","B");
       
        while (!bank.isEmpty()) {
            String n = bank.remove();
            System.out.print(n);
            System.out.print("");
        }
        System.out.println(" ");
    }
}
