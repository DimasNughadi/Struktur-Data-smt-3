/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Latihan;

import java.io.*;

/**
 *
 * @author hp
 */
public class Queue {
    private int maxSize;
    private String[] queArray1;
    private int[] queArray2;
    private int front;
    private int rear;
    private int nItems;

    public Queue(int s) {
        maxSize = s;
        queArray1 = new String[maxSize];
        queArray2 = new int[maxSize];
        front = 0;
        rear = -1;
        nItems = 0;
    }

    public void insertItem(String j) {
        if (rear == maxSize - 1) {
            rear = -1;
        }
        queArray1[++rear] = j;
        nItems++;
    }
    
    public void insertQty(int j) {
        if (rear == maxSize - 1) {
            rear = -1;
        }
        queArray2[++rear] = j;
        nItems++;
    }

    public String removeItem() {
        String temp = queArray1[front++];
        if (front == maxSize) {
            front = 0;
        }
        nItems--;
        return temp;
    }
    
    public int removeQty() {
        int temp = queArray2[front++];
        if (front == maxSize) {
            front = 0;
        }
        nItems--;
        return temp;
    }

    public boolean isEmpty() {
        return (nItems == 0);
    }

    public boolean isFull() {
        return (nItems == maxSize);
    }

    public int size() {
        return nItems;
    }
}
