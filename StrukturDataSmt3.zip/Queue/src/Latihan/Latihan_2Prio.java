/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Latihan;

/**
 *
 * @author hp
 */
class member implements Comparable<member> {

    String name, member;
    int quantity;

    public member(String name, String member, int quantity) {

        this.name = name;
        this.member = member;
        this.quantity = quantity;
    }
    
    public int compareTo(member b) {
        if (quantity > b.quantity) {
            return 1;
        } else if (quantity < b.quantity) {
            return -1;
        } else {
            return 0;
        }
    }
}