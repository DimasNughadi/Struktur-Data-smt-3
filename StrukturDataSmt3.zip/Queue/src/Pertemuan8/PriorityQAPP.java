/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pertemuan8;

import java.io.*;

/**
 *
 * @author DIMAS NUGROHO
 */
public class PriorityQAPP {
    public static void main(String[] args)throws IOException {
        PriorityQ thePQ = new PriorityQ(5);
        
        thePQ.insert(30);
        thePQ.insert(50);
        thePQ.insert(10);
        thePQ.insert(40);
        thePQ.insert(20);
        
        while(!thePQ.isEmpty()){
            double item = thePQ.remove();
            System.out.print(item+" ");            
        }
        System.out.print("");
    }
}
