/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pertemuan8;

import java.util.Scanner;

/**
 *
 * @author hp
 */
public class QueueApp2 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Masukan Panjang Queue: ");
        int panjang = input.nextInt();
        Queue theQueue = new Queue(panjang);
        
        for (int i = 0; i < panjang; i++) {
            System.out.println("Masukan elemen Queue ke-"+(i+1));
            int x = input.nextInt();
            theQueue.insert(x);
        }
        
        System.out.println("\nUrutan keluar elemen dari QUEUE : ");
        while (!theQueue.isEmpty()) {
            int n = theQueue.remove();
            System.out.print(n);
            System.out.print(" ");
        }
        System.out.print("\n");
    }
}
